# UrlEncode

A simple library for URL encoding on Arduino framework.

## Usage

```cpp
#include <UrlEncode.h>

String encoded = urlEncode("http://example.com/path/to/file.html?param=value&param2=value2");
```
